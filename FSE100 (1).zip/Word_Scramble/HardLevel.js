let easyCatBreeds = ["Charteux", "Ocicat", "Manx Cat", "Korat"];
let hardCatBreeds = ["Lykoi", "Javanese Cat", "Sokoke", "Burmilla"];

let allCatBreeds = easyCatBreeds.concat(hardCatBreeds);
let scrambledWords = [];
let inputBoxes = [];
let resultTexts = [];

let canvas;
let submitButton;
let canvasX = 120;
let canvasY = 60;
let img1;
let transparent; 
let meowFont

function preload() {
  img1 = loadImage("../images/1.png");
  transparent = loadImage("../images/transparent.png");
  meowFont = loadFont("../Fonts/Meow.ttf");
  
}

function setup() {

  canvas = createCanvas(600, 600);
  updateCanvasPosition();

  textSize(20);


  for (let i = 0; i < allCatBreeds.length; i++) {
    let scrambled = scrambleWord(allCatBreeds[i]);
    scrambledWords.push(scrambled);

    let input = createInput();
    input.position(canvasX + 270, canvasY + 75 + i * 30);
    input.style('border', '2px solid black');
    inputBoxes.push(input);
    resultTexts.push('');  
  }


  submitButton = createButton('Submit');
  submitButton.position(canvasX + 382, canvasY + 315);
  submitButton.style('border', '2px solid black');
  submitButton.mousePressed(checkAllAnswers);

  level1 = createButton('Level1');
  level1.position(canvasX + 25, canvasY + 525);
  level1.style('border', '2px solid black');
  level1.mousePressed(Level1);





  let buttonOne = createButton('Back To Games');
  buttonOne.position(canvasX + 25, canvasY + 550);
  buttonOne.style('border', '2px solid black');
  buttonOne.mousePressed(Game);
}

function draw() {
 
 background('#fefdf6'); 

  image(transparent, 87, 345, 410, 170);
  

  textAlign(CENTER);
  
  textFont(meowFont);
  
  text('Guess the Cat Breed', width / 2, height / 12);
  text('Level 2', width / 2, height / 12 - 30);

  text('Word Bank', width / 2, height / 2 + 90);
  text('Javanese Cat', width / 2 - 130, height / 2 + 125);
  text('Korat', width / 2 - 35, height / 2 + 125);
  text('Burmilla', width / 2 + 40, height / 2 + 125);
  text('Charteux', width / 2 + 130, height / 2 + 125);
  text('Manx Cat', width / 2 - 130, height / 2 + 155);
  text('Lykoi', width / 2 - 35, height / 2 + 155);
  text('Sokoke', width / 2 + 40, height / 2 + 155);
  text('Ocicat', width / 2 + 128, height / 2 + 155);

  


  for (let i = 0; i < scrambledWords.length; i++) {
    textAlign(LEFT);
    
    fill(0);
    text(`Scrambled: ${scrambledWords[i]}`, 20, 90 + i * 30);  
    text(resultTexts[i], 450, 90 + i * 30); 
  }
}


function scrambleWord(word) {
   
  let wordArray = word.split('');
  for (let i = wordArray.length - 1; i > 0; i--) {
    let j = floor(random(i + 1));
    [wordArray[i], wordArray[j]] = [wordArray[j], wordArray[i]];
  }
  return wordArray.join('');
}


function checkAllAnswers() {
  for (let i = 0; i < allCatBreeds.length; i++) {
    let userGuess = inputBoxes[i].value().trim();


    if (userGuess.toLowerCase() === allCatBreeds[i].toLowerCase()) {
      resultTexts[i] = 'Correct';
    } else {
      resultTexts[i] = 'Try Again';
    }
  }
}


function updateCanvasPosition() {
  canvasX = (windowWidth - width) / 2;
  canvasY = (windowHeight - height) / 2;
  canvas.position(canvasX, canvasY);

  for (let i = 0; i < inputBoxes.length; i++) {
    inputBoxes[i].position(canvasX + 270, canvasY + 80 + i * 30);
  }

  if (submitButton) {
    submitButton.position(canvasX + 250, canvasY + 350);
  }
}


function windowResized() {
  updateCanvasPosition();
}


function Game() {
  window.location.href = '../Game_Menu/games.html';
}
function Level1() {
  window.location.href = '../Word_Scramble/Word_Scamble.html';
}