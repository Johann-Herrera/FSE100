document.getElementById('main').addEventListener('click', function() {
  window.location.href = '../index.html'; 
});

document.getElementById('game1').addEventListener('click', function() {
  window.location.href = "../Word_Scramble/Word_Scamble.html";
});

document.getElementById('game3').addEventListener('click', function () {
  window.location.href = "../Memory_game/memory.html";
});


// function setup() {
//   createCanvas(400, 400);
    
//     let buttonOne = createButton('Word Scamble');
//     buttonOne.position(150, 100);
//     buttonOne.mousePressed(FirstGame); 


// let buttonTwo = createButton('Game 2');
//     buttonTwo.position(150, 150);
//     buttonTwo.mousePressed(SecondGame); 
// }

// function FirstGame() {
//   window.location.href = 'Word_Scamble.html'; 
// }

// function SecondGame() {
//   window.location.href = 'Game2.html'; 
// }

// function draw() {
//   background(220);
// }


// let current = 0;
// let gameOneButton, gameTwoButton, gameThreeButton, backButton;
// let title, gm1, gm2, gm3;
// let word1, word2, word3, word4


// function preload() {
//   title = loadImage('images/cat_background_2.jpg');  
//   gm1 = loadImage('images/Game_1.jpg'); 
//   gm2 = loadImage('images/Game_2.jpg');  
//   gm3 = loadImage('images/Game_3.jpg');  
// }


// function setup() {
//   createCanvas(windowWidth, windowHeight);


//   gameOneButton = createButton('Color Match')
//       .mousePressed(() => current = 1)
//       .position(100, 150);

//   gameTwoButton = createButton('Word Scamble')
//       .mousePressed(() => { 
//           current = 2;
//           loadScript('Word_Scamble.js'); })
//       .position(100, 250);

//   gameThreeButton = createButton('Game 3')
//       .mousePressed(() => current = 3)
//       .position(100, 350);
    
    
    

//   backButton = createButton('Back')
//       .mousePressed(() => current = 0)
//       .position(windowWidth - 150, windowHeight - 50)
//       .hide();

//   textSize(32);
// }

// function draw() {
//   background(title);
//   if (current === 0) {
    
//       text('Welcome!', 200, 100);
//       textSize(52);

     
//       gameOneButton.show();
//       gameTwoButton.show();
//       gameThreeButton.show();
//       backButton.hide();
//   } else {
     
//       gameOneButton.hide();
//       gameTwoButton.hide();
//       gameThreeButton.hide();
//       backButton.show();

     
//       if (current === 1) {
//           image(gm1, 0, 0, width, height); 
//       } else if (current === 2) {
//           image(gm2, 0, 0, width, height);
          
//       } else if (current === 3) {
//           image(gm3, 0, 0, width, height); 
//       }
//   }
// }

// function windowResized() {
//   resizeCanvas(windowWidth, windowHeight);
//   backButton.position(windowWidth - 150, windowHeight - 50);
// }

