 document.getElementById('game').addEventListener('click', function() {
     window.location.href = 'Game_Menu/games.html'; // Replace 'newpage.html' with the target page URL
 });


