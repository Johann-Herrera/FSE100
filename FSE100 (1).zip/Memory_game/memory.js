document.getElementById('main').addEventListener('click', function() {
  window.location.href = '../Game_Menu/games.html'; 
});

document.getElementById('game2').addEventListener('click', function() {
  window.location.href = '../Memory_game/memory_game2.html'; 
});

document.addEventListener('DOMContentLoaded', () => {
  let firstCard = null;
  let secondCard = null;
  let tries = 0;

  
  function shuffleCards() {
    const cards = Array.from(document.querySelectorAll('.card'));
    cards.forEach(card => {
      let randomPosition = Math.floor(Math.random() * cards.length);
      card.style.order = randomPosition;
    });
  }

 
  document.querySelectorAll('.card').forEach(card => {
    card.addEventListener('click', () => {
      
      if (card.classList.contains('matched') || card === firstCard) return;

      card.classList.add('flip');

      if (!firstCard) {
        firstCard = card; 
      } else {
        secondCard = card; 
        tries++;
        document.getElementById('tries').innerText = `Tries: ${tries}`; 
        
        if (firstCard.dataset.card === secondCard.dataset.card) {
          firstCard.classList.add('matched'); 
          secondCard.classList.add('matched'); 
          firstCard = null; 
          secondCard = null; 
        } else {
          
          setTimeout(() => {
            firstCard.classList.remove('flip');
            secondCard.classList.remove('flip');
            firstCard = null; 
            secondCard = null; 
          }, 350);
        }
      }
    });
  });

  shuffleCards(); 
});